# Copy the contents of this file to the pythonanywhere
# WSGI configuration file:  /var/www/<account-name>_pythonanywhere_com_wsgi.py

from wsgi import application  # noqa
