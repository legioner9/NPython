# Copyright: 2011-2013 MoinMoin:ThomasWaldmann
# License: GNU GPL v2 (or any later version), see LICENSE.txt for details.

# Nothing to see here any more, please do direct imports from moin.constants.*
