# for now, see the wikiconfig.py in the toplevel directory.
# TODO: put a tested wiki config in here when stuff has stabilized
