:tocdepth: 2

.. _changes:

Changes in MoinMoin
===================

.. include:: ../changes/CHANGES

.. todo::

   rewrite CHANGES in rst syntax
