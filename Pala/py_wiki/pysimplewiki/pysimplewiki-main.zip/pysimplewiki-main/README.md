# Simple Wiki

[Подробнее](https://github.com/baterflyrity/pysimplewiki/blob/main/wiki/Simple%20Wiki/Главная.md)
