"""Alias to wikiserver.py."""
from engine.wikiserver import main

if __name__ == '__main__':
	main()
