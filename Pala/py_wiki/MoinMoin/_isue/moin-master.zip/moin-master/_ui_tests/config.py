# Copyright: 2012 MoinMoin:HughPerkins
# License: GNU GPL v3 (or any later version), see LICENSE.txt for details.

"""Contains global configuration for functional tests"""

BASE_URL = "http://localhost:8080/"
