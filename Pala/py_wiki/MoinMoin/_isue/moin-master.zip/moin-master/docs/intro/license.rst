.. _license:

=======
License
=======

.. literalinclude:: ../../LICENSE.txt

For a FAQ about the GPL and a copy of the misc. GPL license versions,
please see there: http://www.gnu.org/licenses/gpl.html

This is the GNU GPL version 2. From file docs/licenses/COPYING:

.. literalinclude:: ../licenses/COPYING
